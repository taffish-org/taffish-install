#!/bin/sh

# define if ask
if_ask=true
if_yes=false
now_shell="$(env | grep SHELL=/bin/ | cut -d/ -f 3)"
echo "now-shell: $now_shell"
for arg in $0 "$@"; do
    case $arg in
        --no-ask)
            if_ask=false
            ;;
        -n)
            if_ask=false
            ;;
        -y)
            if_yes=true
            ;;
        --yes)
            if_yes=true
            ;;
    esac
done

here=$(dirname $(realpath $0))
OS_TYPE=$(uname)

mkdir_chmod(){
    mkdir -p $1
    chmod 755 $1
    chmod g+s $1
}

if $here/bin/taf -v & $here/bin/taffish -v
then
    :
else
    echo "The current version is not suitable for your operating system! Please check and re-download!"
    exit 1
fi
wait

if [ $(id -u) -eq 0 ]
then
    echo "!(ROOT) <You are root user, you will install this on your computer for all users!>"
    # check if install with ask
    if $if_yes; then
        echo "[Start Install] ..."
    elif $if_ask; then
        read -p "> Do you want to install taffish to global? (y/n [y]): " answer < /dev/tty
        if [ "$answer" = "n" ] || [ "$answer" = "N" ]; then
            echo "[Stop Install]"
            exit
        else
            echo "[Start Install] ..."
        fi
    else
        echo "[Start Install] ..."
    fi
    global_config=/usr/local/etc/taffish
    global_hub=/usr/local/share/taffish
    global_imgs=$global_hub/images
    global_apps=$global_hub/apps
    global_data=$global_hub/data
    global_temp=$global_hub/temp
    global_info=$global_hub/info
    global_comp=$global_hub/completion
    echo ""
    echo "####################################### ^ #######################################"
    echo "#### Make taffish hub dir"
    echo "#......# <MKDIR: $global_hub + $global_imgs + $global_apps + $global_data + $global_temp + $global_info>"
    echo "##---------------------------------------------------------------------------##"
    mkdir_chmod $global_hub
    mkdir_chmod $global_imgs
    chmod a+rw  $global_imgs
    mkdir_chmod $global_apps
    mkdir_chmod $global_data
    mkdir_chmod $global_temp
    mkdir_chmod $global_info
    mkdir_chmod $global_comp
    echo ""
    echo "####################################### ^ #######################################"
    echo "#### Make taffish config dir & copy config to there"
    echo "#......# <MKDIR: $local_config>"
    echo "#......# <CP: $here/config/* ===> $global_config/>"
    echo "##---------------------------------------------------------------------------##"
    mkdir_chmod $global_config
    # if cp with ask and if cp
    if $if_yes; then
        cp -f $here/config/* $global_config/
    elif $if_ask; then
        cp -i $here/config/* $global_config/
    else
        cp -n $here/config/* $global_config/
    fi
    chmod 755 $global_config/*
    echo ""
    echo "####################################### ^ #######################################"
    echo "#### Copy taffish bin to /usr/local/bin to Make sure everyone can use it"
    echo "#......# <CP: ./bin/taf & taffish ===> /usr/local/bin/>"
    echo "##---------------------------------------------------------------------------##"
    # update may use it, so use -f
    cp -f $here/bin/* /usr/local/bin/
    echo ""
    echo "####################################### ^ #######################################"
    echo "#### Let taf have completion"
    echo "#......# <CP: $here/completion/* ===> /.../completion/>"
    echo "##---------------------------------------------------------------------------##"
    # install taf completion
    cp -f $here/completion/* $global_comp/
    if [ "$now_shell" = "bash" ]
    then
        cp -f $here/completion/* /etc/bash_completion.d/
    else
        echo "\033[33m[Warning]:\033[0m You need to source the completion file by your self: "
        echo "           \033[31mecho \"source $global_comp/*\" >> ~/.\033[0m\033[32m[YOUR-SHELL]\033[0m\033[31mrc\033[0m"
    fi
    echo ""
    echo "####################################### ^ #######################################"
    echo "#### Let Vim can highlight *.taf* files"
    echo "#......# <CP: $here/vim-highlight/* ===> /etc/vim/ & ~/.vim>"
    echo "##---------------------------------------------------------------------------##"
    # check if install vim hightlight with ask
    answer="y"
    if $if_yes; then
        :
    else
        if $if_ask; then
            read -p "> Do you want to install vim highlight? (y/n [y]): " answer < /dev/tty
        fi
    fi
    if [ "$answer" = "n" ] || [ "$answer" = "N" ]; then
        echo "[Skip install vim highlight]"
    else
	    vim_root_path=$(find /usr/share/vim -mindepth 1 -type d -name "vim*" | head -n 1)
        if [ $OS_TYPE = Darwin ]
        then
            echo "<OS: MacOS> ===> ~/.vim/..."
            mkdir -p ~/.vim/syntax
            mkdir -p ~/.vim/ftdetect
            cp -f $here/vim-highlight/syntax/taf.vim ~/.vim/syntax/
            cp -f $here/vim-highlight/ftdetect/taf.vim ~/.vim/ftdetect/
            find ~/.vim/syntax -type f -name "taf.vim"
            ls -la ~/.vim/syntax | grep "taf.vim"
            find ~/.vim/ftdetect -type f -name "taf.vim"
            ls -la ~/.vim/ftdetect | grep "taf.vim"
        elif [ $OS_TYPE = Linux ]
        then
            echo "<OS: Linux> ===> $vim_root_path/..."
            mkdir -p $vim_root_path/syntax
            mkdir -p $vim_root_path/ftdetect
            cp -f $here/vim-highlight/syntax/taf.vim $vim_root_path/syntax/
            cp -f $here/vim-highlight/ftdetect/taf.vim $vim_root_path/ftdetect/
            find $vim_root_path/syntax -type f -name "taf.vim"
            ls -la $vim_root_path/syntax | grep "taf.vim"
            find $vim_root_path/ftdetect -type f -name "taf.vim"
            ls -la $vim_root_path/ftdetect | grep "taf.vim"
        else
            echo "<OS: $OS_TYPE(Unknown)> ===> ???"
            echo "Warning: Ignore make vim hightlight"
        fi
    fi
    echo ""
    echo "[DONE]"
else
    echo "!($(whoami)) <You are not a root user, you only can install this on your own enviroment!>"
    # Check if install with ask
    if $if_yes; then
        echo "[Start Install] ..."
    elif $if_ask; then
        read -p "> Do you want to install taffish to local? (y/n [y]): " answer < /dev/tty
        if [ "$answer" = "n" ] || [ "$answer" = "N" ]; then
            echo "[Stop Install]"
            exit
        else
            echo "[Start Install] ..."
        fi
    else
        echo "[Start Install] ..."
    fi
    local_config=~/.config/taffish
    local_hub=~/.taffish
    local_bin=$local_hub/bin
    local_imgs=$local_hub/images
    local_apps=$local_hub/apps
    local_data=$local_hub/data
    local_temp=$local_hub/temp
    local_info=$local_hub/info
    local_comp=$local_hub/completion
    echo "####################################### ^ #######################################"
    echo "#### Make taffish hub dir"
    echo "#......# <MKDIR: $local_hub + $local_imgs + $local_apps + $local_data + $local_temp + $local_info>"
    echo "##---------------------------------------------------------------------------##"
    mkdir -p $local_hub
    mkdir -p $local_bin
    mkdir -p $local_imgs
    mkdir -p $local_apps
    mkdir -p $local_apps
    mkdir -p $local_data
    mkdir -p $local_temp
    mkdir -p $local_info
    mkdir -p $local_comp
    echo ""
    echo "####################################### ^ #######################################"
    echo "#### Make taffish config dir & copy config to there"
    echo "#......# <MKDIR: $local_config>"
    echo "#......# <CP: $here/config/* ===> $local_config/>"
    echo "##---------------------------------------------------------------------------##"
    mkdir -p $local_config
    # if cp with ask and if cp
    if $if_yes; then
        cp -f $here/config/* $local_config/
    elif $if_ask; then
        cp -i $here/config/* $local_config/
    else
        cp -n $here/config/* $local_config/
    fi
    chmod 755 $local_config/*
    echo ""
    echo "####################################### ^ #######################################"
    echo "#### Copy taffish bin to ~/.taffish/bin & add path to shrc"
    echo "#......# <CP : ./bin/taf & taffish ===> /usr/local/bin/>"
    echo "#......# <ADD: $local_bin ===> .shrc(PATH)>"
    echo "##---------------------------------------------------------------------------##"
    nowsh="$(env | grep SHELL=/bin/ | cut -d/ -f 3)"
    nowshrc=~/."$nowsh"rc
    # update may use it, so use -f
    cp -f $here/bin/* $local_bin/
    addpath_command="export PATH=$local_bin:\$PATH"
    if grep -Fxq "$addpath_command" "$nowshrc"
    then
        echo "You already have it in your $nowshrc [$(grep -Fx "$addpath_command" "$nowshrc")]"
    else
        echo "<Add: $addpath_command ===> $nowshrc>"
        echo "" >> $nowshrc
        echo "# This can add local taffish bin to your own PATH"
        echo $addpath_command | sh
        echo $addpath_command >> $nowshrc
        echo "" >> $nowshrc
    fi
    echo ""
    echo "####################################### ^ #######################################"
    echo "#### Let taf have completion"
    echo "#......# <CP: $here/completion/* ===> ~/.taffish/completion/>"
    echo "##---------------------------------------------------------------------------##"
    # install taf completion
    cp -f $here/completion/* $local_comp/
    if ( grep 'source ~/.taffish/completion/*' $nowshrc > /dev/null 2>&1 )
    then
        :
    else
        echo 'source ~/.taffish/completion/*' >> $nowshrc
    fi
    source $nowshrc
    echo ""
    echo "####################################### ^ #######################################"
    echo "#### Let Vim can highlight *.taf* files"
    echo "#......# <CP: $here/vim-highlight/* ===> ~/.vim/>"
    echo "##---------------------------------------------------------------------------##"
    # check if install vim hightlight with ask
    answer="y"
    if $if_yes; then
        :
    else
        if $if_ask; then
            read -p "> Do you want to install vim highlight? (y/n [y]): " answer < /dev/tty
        fi
    fi
    if [ "$answer" = "n" ] || [ "$answer" = "N" ]; then
        echo "[Skip install vim highlight]"
    else
        mkdir -p ~/.vim/syntax
        mkdir -p ~/.vim/ftdetect
        cp -f $here/vim-highlight/syntax/taf.vim ~/.vim/syntax/
        cp -f $here/vim-highlight/ftdetect/taf.vim ~/.vim/ftdetect/
        find ~/.vim/syntax -type f -name "taf.vim"
        ls -la ~/.vim/syntax | grep "taf.vim"
        find ~/.vim/ftdetect -type f -name "taf.vim"
        ls -la ~/.vim/ftdetect | grep "taf.vim"
    fi
    echo ""
    echo "PS: Taffish may require docker/podman, please install them manually if needed."
    echo ""
    echo "[DONE]"
fi
